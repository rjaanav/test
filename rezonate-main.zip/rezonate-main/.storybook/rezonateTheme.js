import { create } from '@storybook/theming';

export default create({
    fontBase: '"Space Grotesk", sans-serif',
    fontCode: 'monospace',
});