export interface SuccessMessage {
  success: boolean;
  errorMessage?: string;
}
