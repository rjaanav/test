import { IonPage, IonContent } from '@ionic/react';
import React, { useState, useEffect } from 'react';
import CirclesBackground from '../ui/Background/CirclesBackground.svg';
import ControlBar from 'components/ui/controlBar';
import ProfileTopSection from 'components/ui/profileTopSection';
import { User } from 'types/User';
import { getAuth, onAuthStateChanged } from 'firebase/auth';
import ProfileContent from 'components/ui/profileContent';
import getUserInfo from 'utils/getUser';
import { useHistory } from 'react-router-dom';

export default function MyProfile() {
  const [me, setMe] = useState<User>(null);

  const auth = getAuth();
  const history = useHistory();

  useEffect(() => {
    onAuthStateChanged(auth, user => {
      if (user) {
        getUserInfo(user.uid).then(res => {
          // if they're in the database already, just log them in
          if (res) {
            try {
              const date = new Date(res.createdAt);
              const options: Intl.DateTimeFormatOptions = {
                month: 'long',
                day: 'numeric',
                year: 'numeric',
              };
              const formattedDate: string = date.toLocaleDateString('en-US', options);
              setMe({
                id: res.id,
                profileImage: res.profileImage,
                username: res.username,
                email: res.email,
                createdAt: formattedDate,
              });
            } catch (error) {
              console.log(error);
            }
          } else {
            console.log('cant find user with current ID');
          }
        });
      } else {
        history.push('/');
      }
    });
  }, [auth]);

  return (
    <IonPage>
      <IonContent className="ion-page-padding relative px-5 md:px-10" fullscreen>
        {/* <CirclesBackground className="absolute top-0 right-0 z-0" />
        <CirclesBackground className="absolute rotate-180 bottom-0 left-0 z-0" /> */}
        <ControlBar
          logo={false}
          backLink={true}
          centerText={me?.username}
          hasLogout={true}
          profileActions={false}
          isSticky={false}
        />
        <ProfileTopSection {...me}></ProfileTopSection>
        <ProfileContent {...me}></ProfileContent>
      </IonContent>
    </IonPage>
  );
}
