import { IonPage, IonContent } from '@ionic/react';
import React, { useEffect, useState, useLayoutEffect } from 'react';
import SocialLoginContainer from 'components/ui/socialLoginContainer';
import { getAuth, onAuthStateChanged } from 'firebase/auth';
import LoadingScreen from './loadingScreen';
import { Redirect } from 'react-router-dom';
import checkWhitelist from 'utils/checkWhitelist';
import { signMeOut } from 'utils/signMeOut';
import { signInWithGoogle } from 'utils/signInWithGoogle';
import getUserInfo from 'utils/getUser';
import createUser from 'utils/createUser';
import { User } from 'types/User';
import Button from 'components/ui/Button';
import Store from 'store';
import LeftArrowCircle from '../ui/icons/LeftArrowCircle';

export default function Login({}) {
  const [isLoggedIn, setIsLoggedIn] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isNewUser, setIsNewUser] = useState(null);
  const [username, setUsername] = useState('');
  const [newUser, setNewUser] = useState<User>({
    profileImage: '',
    username: username,
    email: '',
    id: '',
  });

  const auth = getAuth();

  useEffect(() => {
    onAuthStateChanged(auth, user => {
      if (user) {
        // if auth check finds a user, check to see if they're whitelisted
        checkWhitelist(user.email).then(res => {
          if (res) {
            // if the user is whitelisted, check to see if they're in the database
            getUserInfo(user.uid).then(res => {
              // if they're in the database already, just log them in
              if (res) {
                Store.update(s => {
                  s.user = user;
                  s.user.profileImage = res?.profileImage;
                  s.user.username = res?.username;
                  s.user.isArtist = res?.isArtist;
                });
                setIsNewUser(false);
                setIsLoggedIn(true);
                setIsLoading(false);
              } else {
                console.log('cant find user with current ID so directing to username form');
                setIsNewUser(true);
                setIsLoggedIn(true);
                setIsLoading(false);
                setNewUser({
                  ...newUser,
                  profileImage: user.photoURL,
                  email: user.email,
                  id: user.uid,
                });
              }
            });
          } else {
            signMeOut();
          }
        });
      } else {
        //console.log('no user found in auth check');
        setIsLoggedIn(false);
        setIsLoading(false);
      }
    });
  }, [auth]);

  function handleUsernameSubmission() {
    createUser(newUser).then(res => {
      if (res.success) {
        setIsNewUser(false);
      } else {
        alert(res.errorMessage);
      }
    });
  }

  function handleInputChange(event) {
    setUsername(event.target.value);
    setNewUser({ ...newUser, username: event.target.value.trim() });
  }

  if (isLoading) {
    //console.log('login screen is loading');
    return <LoadingScreen />;
  } else if (!isLoading && isLoggedIn && !isNewUser) {
    //console.log('login is NOT loading and IS logged in so redirecting');
    return <Redirect to="/" />;
  } else if (!isLoading && isLoggedIn && isNewUser) {
    return (
      <IonPage>
        <IonContent className="ion-page-padding relative px-5 md:px-10 flex" fullscreen>
          <div className="relative flex flex-col justify-center	h-full font-space text-white z-10">
            <h1 className="text-6xl md:text-8xl font-orborn">REZONATE</h1>
            <p className="text-2xl mb-12 font-light">
              Crowdsourcing fan content for artist communities.
            </p>
            <label htmlFor="username" className="font-medium">
              Create A Username
            </label>
            <input
              name="username"
              id="username"
              className="p-2 my-3 rounded bg-white text-black"
              placeholder="Enter username"
              value={username}
              onChange={handleInputChange}
              maxLength={30}
            ></input>
            <Button label={'Submit'} onClick={() => handleUsernameSubmission()}>
              Continue
              <div className="rotate-180 ml-2">
                <LeftArrowCircle />
              </div>
            </Button>
          </div>
        </IonContent>
      </IonPage>
    );
  } else if (!isLoading && !isLoggedIn) {
    //console.log('login is NOT loading and NOT logged so rendering login page');
    return (
      <IonPage>
        <IonContent className="ion-page-padding relative px-5 md:px-10 flex" fullscreen>
          <div className="relative flex flex-col justify-center	h-full font-space text-white z-10">
            <h1 className="text-6xl md:text-8xl font-orborn">REZONATE</h1>
            <p className="text-2xl mb-12 font-light">
              Crowdsourcing fan content for artist communities.
            </p>
            <SocialLoginContainer googleSignIn={signInWithGoogle} />
            {/* <UsernameSelection /> */}
          </div>
        </IonContent>
      </IonPage>
    );
  }
}
