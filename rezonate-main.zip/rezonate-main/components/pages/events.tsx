import { IonPage, IonContent } from '@ionic/react';
import React, { useEffect, useState } from 'react';
import { Event } from '../../types/Event';
import ControlBar from '../ui/controlBar';
import EventCardSmall from '../ui/eventCardSmall';
import EventsFeed from 'components/ui/eventsFeed';
import Dropdown from 'components/ui/dropdown';
import { useSession, getSession } from 'next-auth/react';

export default function Events() {
  const [showNotifications, setShowNotifications] = useState(false);

  return (
    <IonPage>
      <IonContent className="ion-page-padding relative px-5 md:px-10" fullscreen>
        <>
          <ControlBar
            logo={true}
            backLink={false}
            centerText={null}
            hasLogout={false}
            profileActions={true}
            isSticky={true}
          />
          <h1 className="text-7xl	font-space font-bold relative z-10 text-grey mt-10">Events</h1>
          <p className="font-space relative text-base mb-8 z-10 text-lightGrey">
            Enter an event space to share content, interact with the artist and relive the night
            with your event community.
          </p>
          {/* <EventsFeed /> */}
        </>
      </IonContent>
    </IonPage>
  );
}
