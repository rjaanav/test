import { IonPage, IonContent } from '@ionic/react';
import React, { useEffect, useState } from 'react';
import ControlBar from '../ui/controlBar';
import ArtistFeed from 'components/ui/artistFeed';
import { Artist } from 'types/Artist';
import getAllArtists from 'utils/getAllArtists';

export default function DiscoverPage() {
  const [artists, setArtists] = useState<Artist[]>([]);
  const [artistsLoading, setArtistsLoading] = useState(true);

  useEffect(() => {
    if (artistsLoading) {
      if (artists.length <= 0) {
        getAllArtists().then(res => {
          res.sort((a, b) => a.displayName.localeCompare(b.displayName));
          setArtists(res);
          setArtistsLoading(false);
        });
      }
    }
  }, [artists]);

  return (
    <IonPage>
      <IonContent className="ion-page-padding relative px-5 md:px-10" fullscreen>
        <>
          <ControlBar
            logo={true}
            backLink={false}
            centerText={null}
            hasLogout={false}
            profileActions={true}
            isSticky={false}
          />
          <h1 className="text-4xl	font-space font-bold relative z-10 text-grey mt-4	">Discover</h1>
          <p className="font-space relative text-base mb-8 z-10 text-lightGrey font-light	">
            Check out our collection of artists on Rezonate!
          </p>
          {!artistsLoading && <ArtistFeed artistsProp={artists} />}
        </>
      </IonContent>
    </IonPage>
  );
}
