import React, { useEffect, useState } from 'react';
import Comment from '../ui/comment';
import CommentInput from '../ui/commentInput';
import ControlBar from '../ui/controlBar';
import { IonContent, IonPage } from '@ionic/react';
import Store from '../../store';
import getCommentsByPostID from 'utils/getCommentsByPostID';
import createComment from 'utils/createComment';
import { useParams } from 'react-router-dom';

export default function CommentScreen({ match }) {
  const [comments, setComments] = useState([]);
  // const eventID = match.url.split('/')[2];
  // const postID = match.url.split('/')[3];
  const { eventID, postID } = useParams();
  const currentUser = Store.useState(s => s.user);

  async function getComments() {
    getCommentsByPostID(postID, eventID).then(comments => {
      setComments(comments);
    });
  }

  async function createCommentHelper(
    text: string,
    postID: string,
    eventID: string,
    userID: string
  ) {
    createComment(text, postID, eventID, userID).then(comment => {
      setComments([...comments, comment]);
    });
  }

  useEffect(() => {
    if (comments.length < 1) {
      getComments();
    }
  }, []);

  return (
    <IonPage>
      <IonContent>
        <div className="w-full shadow-xl overflow-hidden">
          <div className="px-4 pt-4">
            <ControlBar
              backLink={true}
              centerText={'Comments'}
              hasLogout={false}
              logo={undefined}
              profileActions={undefined}
              isSticky={true}
            />
          </div>
          <div className="flex grow px-5 overflow-scroll mx-auto h-[80vh]">
            <div className="card-body w-full px-0 pb-4 pt-0">
              {comments ? (
                comments.map(comment => {
                  return <Comment key={comment.id} isPreview={false} comment={comment}></Comment>;
                })
              ) : (
                <div className="text-white text-center font-space">No Comments to Show</div>
              )}
            </div>
          </div>
          <CommentInput
            eventID={eventID}
            postID={postID}
            user={currentUser}
            createComment={createCommentHelper}
          ></CommentInput>
        </div>
      </IonContent>
    </IonPage>
  );
}
