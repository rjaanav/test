import { IonPage, IonContent } from '@ionic/react';
import React, { useEffect, useState } from 'react';
import PulseSpinner from 'components/ui/pulseSpinner';

export default function LoadingScreen({}) {
  return (
    <IonPage>
      <IonContent className="ion-page-padding relative px-5 md:px-10 flex" fullscreen>
        <div className="relative flex flex-col justify-center	h-full font-space text-white z-10">
          <PulseSpinner />
        </div>
      </IonContent>
    </IonPage>
  );
}
