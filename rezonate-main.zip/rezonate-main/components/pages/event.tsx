import Card from '../ui/card';

import { IonPage, IonContent } from '@ionic/react';
import React, { useEffect, useState } from 'react';
import { Event } from '../../types/Event';
import ControlBar from '../ui/controlBar';
import Dropdown from '../ui/dropdown';
import Post from '../ui/post';
import PhotoUpload from '../ui/photoUpload';
import { getDownloadURL, ref, uploadBytesResumable, uploadString } from 'firebase/storage';
import { storage } from '../../firebase';
import PostFeed from 'components/ui/postFeed';
import Store from 'store';
import { Post as PostType } from 'types/Post';
import BeatSpinner from 'components/ui/beatSpinner';
import getEventByID from 'utils/getEventByID';
import createPost from 'utils/createPost';
import getPostsByEventID from 'utils/getPostsByEventID';
import b64toBlob from 'b64-to-blob';
import { v4 as uuidv4 } from 'uuid';
import { FilePicker } from '@capawesome/capacitor-file-picker';
import { Camera } from '@capacitor/camera';
import { Device } from '@capacitor/device';
import UploadProgress from 'components/ui/uploadProgress';
import { useParams } from 'react-router-dom';
import UploadToast from 'components/ui/uploadToast';

const sampleEvent: Event = {
  title: 'ANOTR',
  startDateTime: '2023-03-13T03:00:00.000Z',
  buttonLink: '',
  description:
    'Welcome to my event community, thank you so much for joining! Let’s relive the amazing night we had together.',
  flyerImage: 'https://pbs.twimg.com/media/FlJHjUAXkAASu2j?format=jpg&name=large',
  artistMessage:
    'Welcome to my little event community, thank you so much for joining! Let’s relive the amazing night we had together.',
  endDateTime: '',
  updatedAt: '',
  id: 'event-002',
  posts: [
    {
      id: 'post-0002',
      eventID: 'event-002',
      author: { id: 'user-0002', username: 'crazylegshirsch', profileImage: '', email: null },
      videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-blue-ink-swirling-1195-large.mp4',
      comments: [],
      likes: [],
      createdAt: '2023-03-14T03:00:00.000Z',
    },
    {
      id: 'post-0001',
      eventID: 'event-002',
      author: { id: 'user-0002', username: 'crazylegshirsch', profileImage: '', email: null },
      videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-blue-ink-swirling-1195-large.mp4',
      comments: [
        {
          text: 'heyooo',
          user: {
            id: '123',
            username: 'username',
            profileImage: '',
            email: null,
          },
          id: '1',
        },
        {
          text: 'heyooo',
          user: {
            id: '123',
            username: 'username',
            profileImage: '',
            email: null,
          },
          id: '2',
        },
      ],
      likes: ['123'],
      createdAt: '2023-03-13T03:00:00.000Z',
    },
    {
      id: 'post-0001',
      eventID: 'event-002',
      author: { id: 'user-0002', username: 'crazylegshirsch', profileImage: '', email: null },
      videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-blue-ink-swirling-1195-large.mp4',
      comments: [
        {
          text: 'heyooo',
          user: {
            id: '123',
            username: 'username',
            profileImage: '',
            email: null,
          },
          id: '3',
        },
      ],
      likes: ['123', '1233'],
      createdAt: '2023-03-10T03:00:00.000Z',
    },
  ],
  closeDateTime: '2023-04-01T20:20:52.653Z',
  venue: {
    city: 'Washington',
    country: 'US',
    displayName: '99 Scott',
    latitude: 'undefined',
    longitude: 'undefined',
    state: 'DC',
    streetAddress: '2101 New York Ave NE',
    timezone: 'EST',
    zipCode: '20009',
  },
  slug: '',
};

function Events({ match }) {
  const [eventCard, setEventCard] = useState<Event | undefined>(null);
  const [posts, setPosts] = useState([]);
  const [postFailure, setPostFailure] = useState(false);
  const [progress, setProgress] = useState(-1);
  const [postsLoading, setPostsLoading] = useState(null);
  const [videoUrl, setVideoUrl] = useState('');
  const currentUser = Store.useState(s => s.user);
  const { id } = useParams();
  const [uploadSuccess, setUploadSuccess] = useState(false);
  const [isLiveEvent, setIsLiveEvent] = useState(false);

  useEffect(() => {
    if (!eventCard) {
      getEventByID(id).then(res => {
        setEventCard(res);
        const date = new Date().toISOString();
        setIsLiveEvent(date < res.closeDateTime && date > res.startDateTime);
      });
      if (!videoUrl) {
        // getVideoSrc();
      }
    }
    getPosts();
  }, [eventCard, videoUrl]);

  async function createPostHelper(videoUrl: string, postID: string, eventID: string) {
    if (currentUser) {
      let newPost: PostType;
      newPost = {
        videoUrl: videoUrl,
        id: postID,
        eventID: eventID,
        likes: [],
        comments: [],
        createdAt: new Date().toISOString(),
        author: {
          id: currentUser.uid,
          username: currentUser.username,
          profileImage: currentUser.profileImage,
          email: null,
        },
      };

      await createPost(videoUrl, postID, eventID, newPost.author.id).then(res => {
        if (res) {
          setPosts([newPost, ...posts]);
          setProgress(-1);
          handleUploadSuccess();
        } else {
          setPostFailure(true);
        }
      });
    }
  }

  function getPosts() {
    setPostsLoading(true);
    getPostsByEventID(id).then(posts => {
      if (posts) {
        setPosts(posts);
      } else {
        setPosts([]);
      }
      setPostsLoading(false);
    });
  }

  function sortPosts(sortMethod: string) {
    if (posts.length <= 0) {
      return;
    }
    let tempPosts;
    const sortOptions: string[] = ['Recently Uploaded', 'Most Likes', 'Most Comments'];
    if (sortMethod == sortOptions[0]) {
      tempPosts = [].concat(posts).sort(function (a, b) {
        return a.createdAt < b.createdAt ? 1 : a.createdAt > b.createdAt ? -1 : 0;
      });
      setPosts(tempPosts);
    } else if (sortMethod == sortOptions[1]) {
      tempPosts = [].concat(posts).sort(function (a, b) {
        return b.likes.length < a.likes.length ? -1 : b.likes.length > a.likes.length ? 1 : 0;
      });
      setPosts(tempPosts);
    } else if (sortMethod == sortOptions[2]) {
      tempPosts = [].concat(posts).sort(function (a, b) {
        return b.comments.length < a.comments.length
          ? -1
          : b.comments.length > a.comments.length
          ? 1
          : 0;
      });
      setPosts(tempPosts);
    }
  }

  function clearUpload() {
    setProgress(-1);
    setPostFailure(false);
  }

  function handleUploadSuccess() {
    setUploadSuccess(true);
    const timerId = setTimeout(() => {
      setUploadSuccess(false);
    }, 2500);
  }

  const handleChange = event => {
    try {
      if (!currentUser.uid) {
        throw new Error('User not logged in. Cannot post.');
      }
      const newPostID = uuidv4();
      const reader = new FileReader();
      reader.addEventListener('load', () => {
        let base64Data = reader.result as string;
        var contentType = 'video/mp4';
        base64Data = base64Data.split(',').pop();
        setProgress(1);
        var blob = b64toBlob(base64Data, contentType);
        const storageRef = ref(storage, `events/${eventCard.id}/${newPostID}/video.mp4`);
        const uploadVideo = uploadBytesResumable(storageRef, blob);

        uploadVideo.on(
          'state_changed',
          snapshot => {
            // Get task progress, including the number of bytes uploaded and the total number of bytes to be uploaded
            const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
            setProgress(progress);
            console.log('Upload is ' + progress + '% done');
            switch (snapshot.state) {
              case 'paused':
                console.log('Upload is paused');
                break;
              case 'running':
                console.log('Upload is running');
                break;
            }
          },
          error => {
            setPostFailure(true);
            switch (error.code) {
              case 'storage/unauthorized':
                // User doesn't have permission to access the object
                break;
              case 'storage/canceled':
                // User canceled the upload
                break;

              case 'storage/unknown':
                // Unknown error occurred, inspect error.serverResponse
                break;
            }
          },
          () => {
            // mark process as finished
            getDownloadURL(uploadVideo.snapshot.ref).then(downloadURL => {
              createPostHelper(downloadURL, newPostID, eventCard.id);
            });
          }
        );
      });
      reader.readAsDataURL(event.target.files[0]);
    } catch (error) {
      console.log(error);
      setPostFailure(true);
    }
  };

  const pickImages = async () => {
    const newPostID = uuidv4();
    const persmissions = await Camera.checkPermissions();
    const info = await Device.getInfo();
    let videoBlob;
    let b64;
    const storageRef = ref(storage, `events/${eventCard.id}/${newPostID}/video.mp4`);

    await FilePicker.pickVideos({
      multiple: false,
      readData: true,
    })
      .then(async res => {
        //TODO: Implement file upload restrictions
        // if (res.files[0].size > 5000000) {
        //   console.log('file too large');
        //   throw new Error('File too large');
        // }

        setProgress(1);
        // TODO: blob upload much faster, implement later
        uploadString(storageRef, res.files[0].data, 'base64').then(snapshot => {
          console.log('Uploaded video successfully');
          getDownloadURL(snapshot.ref).then(downloadURL => {
            createPostHelper(downloadURL, newPostID, eventCard.id);
          });
        });
      })
      .catch(error => {
        console.log('Error uploading video: ', error);
        return;
      });
  };

  return (
    <IonPage className="relative z-10">
      <IonContent className="ion-page-padding relative md:px-0" fullscreen>
        <UploadToast uploadSuccess={uploadSuccess} />
        <ControlBar
          logo={false}
          backLink={true}
          centerText={''}
          hasLogout={false}
          profileActions={false}
          isSticky={true}
        />
        {/* <Notifications open={showNotifications} onDidDismiss={() => setShowNotifications(false)} /> */}
        {(progress > 0 || postFailure) && (
          <UploadProgress progress={progress} postFailure={postFailure} clearUpload={clearUpload} />
        )}
        <div id="feed" className="w-96 max-w-full mx-auto">
          {eventCard && (
            <Card
              key={eventCard.id}
              showDetails={true}
              event={eventCard}
              type={undefined}
              props={undefined}
            />
          )}
          {postsLoading ? (
            <div className="my-20">
              <BeatSpinner />
            </div>
          ) : (
            <>
              {posts.length > 0 && <Dropdown sortPosts={sortPosts} />}
              <PostFeed PostCards={posts} />
            </>
          )}
          {eventCard && currentUser && isLiveEvent && (
            <PhotoUpload progress={progress} pickImages={pickImages} handleChange={handleChange} />
          )}
        </div>
      </IonContent>
    </IonPage>
  );
}

export default Events;
