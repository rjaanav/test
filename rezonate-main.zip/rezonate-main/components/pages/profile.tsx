import Image from 'next/legacy/image';
import Card from '../ui/card';

import { IonPage, IonContent } from '@ionic/react';
import React, { useState } from 'react';
import { notificationsOutline } from 'ionicons/icons';
import { getEventCard, getHomeItems } from '../../store/selectors';
import Store from '../../store';
import CirclesBackground from '../ui/Background/CirclesBackground.svg';
import { Event } from '../../types/Event';
import ControlBar from 'components/ui/controlBar';
import Dropdown from 'components/ui/dropdown';
import ProfileTopSection from 'components/ui/profileTopSection';

export default function MyProfile() {
  return (
    <IonPage>
      <IonContent className="ion-page-padding relative px-5 md:px-10" fullscreen>
        <CirclesBackground className="absolute top-0 right-0 z-0" />
        <CirclesBackground className="absolute rotate-180 bottom-0 left-0 z-0" />
        <ControlBar
          backLink={false}
          centerText={null}
          hasLogout={true}
          logo={undefined}
          profileActions={undefined}
          isSticky={false}
        />
        <ProfileTopSection id={''} profileImage={''} username={''} email={null}></ProfileTopSection>
      </IonContent>
    </IonPage>
  );
}
