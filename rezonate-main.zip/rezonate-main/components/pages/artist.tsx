import { IonPage, IonContent } from '@ionic/react';
import React, { useEffect, useState } from 'react';
import { Event } from '../../types/Event';
import ControlBar from '../ui/controlBar';
import EventsFeed from 'components/ui/eventsFeed';
import { Artist } from 'types/Artist';
import getArtistByID from 'utils/getArtistByID';
import styles from './artist.module.css';

const sampleEvent: Event = {
  title: 'ANOTR',
  startDateTime: '2023-03-13T03:00:00.000Z',
  buttonLink: '',
  description:
    'Welcome to my event community, thank you so much for joining! Let’s relive the amazing night we had together.',
  flyerImage: 'https://pbs.twimg.com/media/FlJHjUAXkAASu2j?format=jpg&name=large',
  artistMessage:
    'Welcome to my little event community, thank you so much for joining! Let’s relive the amazing night we had together.',
  endDateTime: '',
  updatedAt: '',
  id: 'event-002',
  posts: [
    {
      id: 'post-0002',
      eventID: 'event-002',
      author: { id: 'user-0002', username: 'crazylegshirsch', profileImage: '', email: null },
      videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-blue-ink-swirling-1195-large.mp4',
      comments: [],
      likes: [],
      createdAt: '2023-03-14T03:00:00.000Z',
    },
    {
      id: 'post-0001',
      eventID: 'event-002',
      author: { id: 'user-0002', username: 'crazylegshirsch', profileImage: '', email: null },
      videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-blue-ink-swirling-1195-large.mp4',
      comments: [
        {
          text: 'heyooo',
          user: {
            id: '123',
            username: 'username',
            profileImage: '',
            email: null,
          },
          id: '1',
        },
        {
          text: 'heyooo',
          user: {
            id: '123',
            username: 'username',
            profileImage: '',
            email: null,
          },
          id: '2',
        },
      ],
      likes: ['123'],
      createdAt: '2023-03-13T03:00:00.000Z',
    },
    {
      id: 'post-0001',
      eventID: 'event-002',
      author: { id: 'user-0002', username: 'crazylegshirsch', profileImage: '', email: null },
      videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-blue-ink-swirling-1195-large.mp4',
      comments: [
        {
          text: 'heyooo',
          user: {
            id: '123',
            username: 'username',
            profileImage: '',
            email: null,
          },
          id: '3',
        },
      ],
      likes: ['123', '1233'],
      createdAt: '2023-03-10T03:00:00.000Z',
    },
  ],
  closeDateTime: '2023-04-01T20:20:52.653Z',
  venue: {
    city: 'Washington',
    country: 'US',
    displayName: 'Culture',
    latitude: 'undefined',
    longitude: 'undefined',
    state: 'DC',
    streetAddress: '2101 New York Ave NE',
    timezone: 'EST',
    zipCode: '20009',
  },
  slug: '',
};

const sampleArtist: Artist = {
  user: {
    profileImage: 'https://i.scdn.co/image/ab6761610000e5ebaf45366fa79ad2592c599eee',
    id: '001',
    username: 'will-clarke',
    email: null,
  },
  displayName: 'Will Clarke',
  communityMessage:
    'Welcome to my little event community, thank you so much for joining! Let’s relive the amazing night we had together.',
  events: [sampleEvent],
};

export default function ArtistPage({ match }) {
  const [artist, setArtist] = useState(null);

  useEffect(() => {
    if (!artist) {
      getArtistByID(match.params.id).then(artist => {
        setArtist(artist);
      });
    }
  }, [artist]);

  return (
    <IonPage>
      <IonContent className="ion-page-padding relative px-5 md:px-10" fullscreen>
        <>
          <ControlBar
            logo={true}
            backLink={false}
            centerText={null}
            hasLogout={false}
            profileActions={true}
            isSticky={false}
          />
          <div
            className={`absolute rounded-full overflow-hidden w-[125px] left-0 right-0 mx-auto top-10 ${styles.artistImageContainer}`}
          >
            <img
              className="object-cover min-h-full w-full aspect-square"
              src={artist?.user?.profileImage}
              alt="Artist Image"
            />
          </div>
          <h1 className="text-5xl font-space font-bold relative z-10 text-grey mt-[90px]">
            {artist?.displayName}
          </h1>
          <p className="font-space relative text-base mb-8 z-10 text-lightGrey font-light">
            {artist?.communityMessage}
          </p>
          {artist?.events && <EventsFeed eventsProp={artist?.events} />}
        </>
      </IonContent>
    </IonPage>
  );
}
