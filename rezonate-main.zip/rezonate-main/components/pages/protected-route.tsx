import { getAuth, onAuthStateChanged } from 'firebase/auth';
import { IonPage, IonContent, IonRouterLink } from '@ionic/react';

import React, { useEffect, useState } from 'react';
import { Redirect } from 'react-router-dom';
import Store from '../../store';

import LoadingScreen from './loadingScreen';
import getUserInfo from 'utils/getUser';
import MapPin from '../ui/MapPin';
import Lock from 'components/ui/icons/lock';
import ControlBar from 'components/ui/controlBar';
import Button from 'components/ui/Button';
import { useHistory } from 'react-router-dom';

const ProtectedRoute = ({ component: Component, ...rest }) => {
  const [authenticated, setAuthenticated] = useState(Store.useState(s => s.user));
  const [isLoading, setIsLoading] = useState(true);
  const auth = getAuth();
  const history = useHistory();
  //console.log('executing protected route');

  useEffect(() => {
    onAuthStateChanged(auth, user => {
      //console.log('executing auth check in protected route');

      if (user) {
        getUserInfo(user.uid).then(res => {
          Store.update(s => {
            s.user = user;
            s.user.profileImage = res?.profileImage;
            s.user.username = res?.username;
          });
        });
        //console.log('found a user', user);
        setIsLoading(false);
        setAuthenticated(true);
      } else {
        //console.log('no user found in auth check');
        setIsLoading(false);
        setAuthenticated(false);
      }
    });
  }, [auth]);

  // popup that prompts user to go to /login or back to /discover
  function SignInPrompt() {
    // function handleSignUp() {
    //   history.push('/login');
    // }
    return (
      <IonContent className="ion-page-padding relative px-5 md:px-10 flex" fullscreen>
        <ControlBar
          backLink={true}
          hasLogout={false}
          logo={false}
          profileActions={false}
          isSticky={false}
        />
        <div className="card w-full sm:w-96 bg-white shadow-xl mx-auto">
          <figure>
            <img className="object-cover w-full max-h-60" src={''} alt="Shoes" />
          </figure>
          <div className="card-body pt-4 pb-6 gap-0 px-6">
            <p className="font-space text-lightBlack text-base uppercase font-bold">Jan 1st</p>
            <h2 className="card-title font-space text-black text-4xl mt-2">Rezonate Event</h2>
            <div className="flex flex-row">
              <MapPin />
              <p className="font-space text-black ml-1 text-base font-light	">Rezonate HQ</p>
            </div>

            <div className="font-space mt-4">
              <p className="text-black font-bold mb-2">Message from the artist:</p>
              <p className="text-black font-light	">
                Hello fake message Hello fake message Hello fake message Hello fake message
              </p>
            </div>
          </div>
        </div>
        <div
          className="absolute top-0 left-0 w-screen h-screen flex flex-col items-center z-50"
          style={{ backdropFilter: 'blur(8px)', backgroundColor: 'rgba(0, 0, 0, 0.5)' }}
        >
          <div className="w-10/12 bg-white mt-32 h-auto flex flex-col items-center pt-12 pb-6 rounded-lg">
            <Lock></Lock>
            <h3 className="card-title font-space text-black text-4x mb-4 mt-6">
              Event feed restricted
            </h3>
            <p className=" text-black text-sm w-4/5 font-light	">
              You must be signed in to view and share content from this event. Sign up now, it only
              takes a second!
            </p>
            <IonRouterLink href="/login" className="w-4/5">
              <Button
                className="btn btn-primary rounded w-full font-space mt-4 mb-2 text-white"
                label={'Sign me up!'}
              >
                Sign me up!
              </Button>
            </IonRouterLink>
            <IonRouterLink href="/discover" className="w-4/5">
              <Button
                className="btn rounded w-full font-space text-black bg-white border-1 border-black border-solid"
                label={'no thanks'}
              >
                No thanks
              </Button>
            </IonRouterLink>
          </div>
        </div>
      </IonContent>
    );
  }

  if (isLoading) {
    //console.log('its loading');
    return <LoadingScreen />;
  } else if (!isLoading && authenticated) {
    //console.log('its NOT loading and IS authenticated');
    return <Component {...rest} />;
  } else if (!isLoading && !authenticated) {
    //console.log('its NOT loading and NOT authenticated');
    return <SignInPrompt />;
  }
};

export default ProtectedRoute;

// Wrapper component for each component in app router

// set loading status (in store) to true
// check loading status
// --> if true
// ------> render loading screen
// if false
// ------> render page
// auth check
//  --> if user
// ------> set loading false, set user in store, return child component
// --> if no user
// -------> redirect to /login, set loading false
