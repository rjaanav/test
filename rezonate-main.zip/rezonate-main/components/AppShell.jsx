import { IonApp, IonRouterOutlet, setupIonicReact } from '@ionic/react';
import { cog, flash, list } from 'ionicons/icons';
import { StatusBar, Style } from '@capacitor/status-bar';

import { IonReactRouter } from '@ionic/react-router';
import { Route, Redirect } from 'react-router-dom';
import { getAuth, onAuthStateChanged } from 'firebase/auth';
import { useEffect, useState } from 'react';
import Store from '../store';

import DiscoverPage from './pages/discover';
import ArtistPage from './pages/artist';
import Events from './pages/events';
import Event from './pages/event';
import CommentScreen from './pages/comments';
import Login from './pages/login';
import MyProfile from './pages/my-profile';
import CirclesBackground from './ui/Background/CirclesBackground.svg';

import ProtectedRoute from './pages/protected-route';

setupIonicReact({});

const setStatusBarStyleDark = async () => {
  await StatusBar.setStyle({ style: Style.Dark });
};

const AppShell = () => {
  if (Capacitor.isNativePlatform()) {
    setStatusBarStyleDark();
  }
  return (
    <IonApp>
      <IonReactRouter>
        <IonRouterOutlet id="main" className="z-10 pt-6">
          <Route path="/" render={() => <Redirect to="/discover" />} exact={true} />
          <Route path="/my-profile" component={MyProfile} exact={true} />
          <Route path="/login" render={() => <Login />} />
          <Route path="/discover" component={DiscoverPage} exact={true} />
          <Route path="/artists/:id" component={ArtistPage} exact={true} />
          <Route
            path="/events/:id"
            exact={true}
            render={() => <ProtectedRoute component={Event} />}
          />
          <Route
            path="/events/:eventID/:postID"
            render={() => <ProtectedRoute component={CommentScreen} />}
            exact={true}
          />
        </IonRouterOutlet>
      </IonReactRouter>
      <CirclesBackground className="absolute top-0 right-0 z-0" />
      <CirclesBackground className="absolute rotate-180 bottom-0 left-0 z-0" />
    </IonApp>
  );
};

export default AppShell;
