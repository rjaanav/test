import React, { useEffect, useState } from 'react';
import { Event } from 'types/Event';
import ArtistCardSmall from './artistCardSmall';
import { Artist } from 'types/Artist';
import getAllArtists from 'utils/getAllArtists';

const sampleEvent: Event = {
  title: 'ANOTR',
  startDateTime: '2023-03-13T03:00:00.000Z',
  buttonLink: '',
  description:
    'Welcome to my event community, thank you so much for joining! Let’s relive the amazing night we had together.',
  flyerImage: 'https://pbs.twimg.com/media/FlJHjUAXkAASu2j?format=jpg&name=large',
  artistMessage:
    'Welcome to my little event community, thank you so much for joining! Let’s relive the amazing night we had together.',
  endDateTime: '',
  updatedAt: '',
  id: 'event-002',
  posts: [
    {
      id: 'post-0002',
      eventID: 'event-002',
      author: { id: 'user-0002', username: 'crazylegshirsch', profileImage: '', email: null },
      videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-blue-ink-swirling-1195-large.mp4',
      comments: [],
      likes: [],
      createdAt: '2023-03-14T03:00:00.000Z',
    },
    {
      id: 'post-0001',
      eventID: 'event-002',
      author: { id: 'user-0002', username: 'crazylegshirsch', profileImage: '', email: null },
      videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-blue-ink-swirling-1195-large.mp4',
      comments: [
        {
          text: 'heyooo',
          user: {
            id: '123',
            username: 'username',
            profileImage: '',
            email: null,
          },
          id: '1',
        },
        {
          text: 'heyooo',
          user: {
            id: '123',
            username: 'username',
            profileImage: '',
            email: null,
          },
          id: '2',
        },
      ],
      likes: ['123'],
      createdAt: '2023-03-13T03:00:00.000Z',
    },
    {
      id: 'post-0001',
      eventID: 'event-002',
      author: { id: 'user-0002', username: 'crazylegshirsch', profileImage: '', email: null },
      videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-blue-ink-swirling-1195-large.mp4',
      comments: [
        {
          text: 'heyooo',
          user: {
            id: '123',
            username: 'username',
            profileImage: '',
            email: null,
          },
          id: '3',
        },
      ],
      likes: ['123', '1233'],
      createdAt: '2023-03-10T03:00:00.000Z',
    },
  ],
  closeDateTime: '2023-04-01T20:20:52.653Z',
  venue: {
    city: 'Washington',
    country: 'US',
    displayName: 'Culture',
    latitude: 'undefined',
    longitude: 'undefined',
    state: 'DC',
    streetAddress: '2101 New York Ave NE',
    timezone: 'EST',
    zipCode: '20009',
  },
  slug: '',
};

const sampleArtist: Artist = {
  user: {
    id: '001',
    profileImage: 'https://i.scdn.co/image/ab6761610000e5ebaf45366fa79ad2592c599eee',
    username: 'will-clarke',
    createdAt: '2023-03-10T03:00:00.000Z',
    email: null,
  },
  displayName: 'Will Clarke',
  communityMessage:
    'Welcome to my little event community, thank you so much for joining! Let’s relive the amazing night we had together.',
  events: [sampleEvent],
};

type AllEvents = {
  live: Event[];
  upcoming: Event[];
};

enum TabType {
  LIVE = 'live',
  UPCOMING = 'upcoming',
}

function ArtistFeed({ artistsProp }) {
  const [artists, setArtists] = useState<Artist[]>(artistsProp);

  return (
    <div>
      <div className="grid gap-5">
        {artists?.length > 0 ? (
          artists.map((artist: Artist) => {
            return (
              <ArtistCardSmall
                key={artist.user.id}
                artist={artist}
                type={undefined}
                props={undefined}
              />
            );
          })
        ) : (
          <p className="text-white text-xl text-center font-space mt-16">No artists to show</p>
        )}
      </div>
    </div>
  );
}

export default ArtistFeed;
