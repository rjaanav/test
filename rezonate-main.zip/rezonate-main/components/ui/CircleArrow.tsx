import React from 'react';
import ArrowRightCircle from './icons/ArrowRightCircle.svg';
import ArrowLeftCircle from './icons/ArrowLeftCircle.svg';

type ArrowProps = {
  direction: string;
};

function CircleArrow({ direction }: ArrowProps) {
  return <ArrowRightCircle className="ml-1" />;
}

export default CircleArrow;
