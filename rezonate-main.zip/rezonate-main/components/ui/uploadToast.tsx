import React from 'react';
import Success from './icons/success';
import styles from './uploadToast.module.css';
import resolveConfig from 'tailwindcss/resolveConfig';
import tailwindConfig from '../../tailwind.config.js';

const fullConfig = resolveConfig(tailwindConfig);

export default function UploadToast({ uploadSuccess }) {
  return (
    <div className={`sticky w-min h-0 inset-0	mx-auto z-50	`}>
      <div
        className={`px-6 h-9 flex justify-center items-center text-white bg-lightGreen rounded-full	${
          uploadSuccess ? styles.slideIn : styles.slideOut
        }`}
      >
        <p className="pl-1.5 text-successGreen mr-3">Success</p>
        <Success color={fullConfig.theme.colors.successGreen} />
      </div>
    </div>
  );
}
