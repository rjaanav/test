import React, { CSSProperties } from 'react';
import PuffLoader from 'react-spinners/PuffLoader';

const override: CSSProperties = {
  position: 'absolute',
  margin: 'auto auto',
  borderColor: 'red',
  left: 0,
  right: 0,
  top: 0,
  bottom: 0,
};

export default function PulseSpinner() {
  return (
    <div className="m-auto">
      <PuffLoader
        color={'#2F20A3'}
        loading={true}
        size={150}
        aria-label="Loading Spinner"
        data-testid="loader"
        speedMultiplier={2}
        cssOverride={override}
      />
      <PuffLoader
        color={'#2F20A3'}
        loading={true}
        size={100}
        aria-label="Loading Spinner"
        data-testid="loader"
        speedMultiplier={2}
        cssOverride={override}
      />
      <PuffLoader
        color={'#2F20A3'}
        loading={true}
        size={50}
        aria-label="Loading Spinner"
        data-testid="loader"
        speedMultiplier={2}
        cssOverride={override}
      />
    </div>
  );
}
