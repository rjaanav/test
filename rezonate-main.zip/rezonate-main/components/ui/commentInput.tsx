import React, { useState } from 'react';
import { Comment as CommentType } from '../../types/Comment';
import Avatar from './icons/Avatar';
import PaperPlane from './icons/PaperPlane';
import DOMPurify from 'dompurify';
import { IonRouterLink } from '@ionic/react';
import Button from './Button';
import Username from './username';

export default function CommentInput({ eventID, postID, user, createComment }) {
  const [inputValue, setInputValue] = useState('');

  const handleChange = event => {
    setInputValue(DOMPurify.sanitize(event.target.value));
  };

  function handlePostComment(e) {
    e.preventDefault();

    if (inputValue.length > 0) {
      console.log(inputValue);
      // sanitize twice for security
      const sanitizedValue = DOMPurify.sanitize(inputValue);
      // send to DB using postID, eventID, and user

      createComment(sanitizedValue, postID, eventID, user.uid).then(res => {
        // reset state for multiple comments
        setInputValue('');
      });
    }
  }

  return (
    <div className="absolute bottom-0 w-full bg-white flex flex-col items-start px-5 py-3 rounded-t-[20px] z-50">
      {user ? (
        <>
          <div className="flex flex-row items-center pb-2">
            <div className="avatar w-8 mr-2">
              <Username key={''} user={user} type={undefined} props={undefined} />
            </div>
            <p className="text-black leading-5 font-medium text-sm">{user.username}</p>
          </div>
          <div className="w-full border rounded px-3 h-10 text-black border-lightGrey">
            <form onSubmit={handlePostComment} className="flex h-full px-1">
              <input
                type="text"
                placeholder="Enter Comment"
                className="w-full bg-white focus:outline-none"
                onChange={handleChange}
                value={inputValue}
              />
              <button type="submit">
                <PaperPlane></PaperPlane>
              </button>
            </form>
          </div>
        </>
      ) : (
        <div className="flex w-full flex-col text-black">
          <p className="font-space w-full mb-2 text-center text-xl">
            Sign in to join the conversation!
          </p>
          <IonRouterLink href={`/login`} className="w-full">
            <Button label="login">Login</Button>
          </IonRouterLink>
        </div>
      )}
    </div>
  );
}
