import React from 'react';
import Clock from './icons/clock';
import Countdown from 'react-countdown';

const CountdownTimer = ({ targetDate, isSmall }) => {
  let description = isSmall ? 'Closing in' : 'This feed closes in';
  // Completed state
  const Completionist = () => (
    <div className="ml-2 flex font-light font-space">
      {description}
      <p className="ml-2 text-errorRed font-bold">0hr 0min 0s</p>
    </div>
  );

  function ClockIcon() {
    let className = '';
    if (isSmall) {
      className = 'w-4 h-4 xs:w-6 xs:h-6';
    } else {
      className = 'w-6 h-6';
    }
    return (
      <div className={className}>
        <Clock />
      </div>
    );
  }

  // Renderer callback with condition
  const renderer = ({ days, hours, minutes, seconds, completed }) => {
    if (completed) {
      // Render a completed state
      return <Completionist />;
    } else {
      // Render a countdown
      return (
        <div className="ml-2 flex font-light font-space">
          {description}
          <p className="ml-1 text-errorRed font-bold">
            {days ? `${days}d` : ''} {hours}h {minutes}m {days ? '' : `${seconds}s`}
          </p>
        </div>
      );
    }
  };

  return (
    <div className="flex text-black items-center">
      <ClockIcon />
      <Countdown date={targetDate} renderer={renderer} />
    </div>
  );
};

export default CountdownTimer;
