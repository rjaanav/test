import React from 'react';
import { User } from 'types/User';

function ProfileContent(user: User) {
  return (
    <div className="flex mt-40 items-center justify-center">
      {/* <div className="font-space text-center text-xl">
        We’re working on showing you more information about this user.
      </div> */}
    </div>
  );
}

export default ProfileContent;
