import React, { useEffect, useState } from 'react';
import EventCardSmall from './eventCardSmall';
import { Event } from 'types/Event';
import styles from './eventsFeed.module.css';
import Store from '../../store';
import { useParams } from 'react-router-dom';

const sampleEvent: Event = {
  title: 'Will Clarke',
  startDateTime: '2023-03-13T03:00:00.000Z',
  buttonLink: '',
  description:
    'Welcome to my event community, thank you so much for joining! Let’s relive the amazing night we had together.',
  flyerImage:
    'https://imgproxy.ra.co/_/quality:66/w:1500/rt:fill/aHR0cHM6Ly9pbWFnZXMucmEuY28vMmMzODQ2OWQyNDQ2OWU4N2U2ZTI4MzE0ZDExNDM1YWI2ZDJiZGRiMy5qcGc=',
  artistMessage:
    'Welcome to my little event community, thank you so much for joining! Let’s relive the amazing night we had together.',
  endDateTime: '',
  updatedAt: '',
  id: 'event-002',
  slug: 'event-002',
  closeDateTime: '2023-03-20T03:20:52.653Z',
  venue: {
    city: 'Washington',
    country: 'US',
    displayName: 'Culture',
    latitude: 'undefined',
    longitude: 'undefined',
    state: 'DC',
    streetAddress: '2101 New York Ave NE',
    timezone: 'EST',
    zipCode: '20009',
  },
  posts: [],
};

type AllEvents = {
  live: Event[];
  upcoming: Event[];
  past: Event[];
};

enum TabType {
  LIVE = 'live',
  UPCOMING = 'upcoming',
  PAST = 'past',
}

function EventsFeed({ eventsProp }) {
  const [events, setEvents] = useState<AllEvents>({
    live: [],
    upcoming: [],
    past: [],
  });
  const [eventsLoading, setEventsLoading] = useState(true);
  const [currentTab, setCurrentTab] = useState(TabType.LIVE);
  const [isArtist, setIsArtist] = useState(Store.useState(s => s.user?.isArtist));
  let storeUsername = Store.useState(s => {
    let username = s.user?.username;
    return username ? username : '';
  });
  const pageUsername = useParams().id;

  function orderEvents() {
    if (!eventsProp || eventsProp.length <= 0) return;
    const result = {
      live: [],
      upcoming: [],
      past: [],
    };
    let date = new Date();
    eventsProp.forEach(event => {
      let eventStartDate = new Date(event.startDateTime);
      let eventEndDate = new Date(event.closeDateTime);
      if (eventStartDate > date) {
        result.upcoming.push(event);
      } else if (eventStartDate <= date && eventEndDate > date) {
        result.live.push(event);
      } else {
        result.past.push(event);
      }
    });
    setEvents(result);
    setEventsLoading(false);
  }

  function isActive() {
    return isArtist == true && pageUsername == storeUsername;
  }

  useEffect(() => {
    if (eventsLoading) {
      orderEvents();
    }
  }, [events]);

  function handleTabClick(e) {
    setCurrentTab(e.target.id);
    const tabs = document.getElementsByClassName(styles.tab);
    Array.from(tabs).forEach(function (tab) {
      if (tab.id == e.target.id) {
        e.target.classList.add(styles.active);
      } else {
        tab.classList.remove(styles.active);
      }
    });
  }

  return (
    <div>
      <div className="flex relative gap-2 w-fit-content mb-8">
        <button
          id={TabType.LIVE}
          onClick={e => handleTabClick(e)}
          className={`${styles.tab} ${styles.active}`}
        >
          Live Now
        </button>
        <button id={TabType.UPCOMING} onClick={e => handleTabClick(e)} className={styles.tab}>
          Upcoming
        </button>
        <button id={TabType.PAST} onClick={e => handleTabClick(e)} className={styles.tab}>
          Past
        </button>
      </div>
      {currentTab == TabType.LIVE && (
        <div className="grid gap-5">
          {events?.live.length > 0 ? (
            events.live.map((event: Event) => {
              return (
                <EventCardSmall
                  key={event.slug}
                  event={event}
                  type={undefined}
                  props={undefined}
                  isInactive={false}
                  showCountdown={true}
                />
              );
            })
          ) : (
            <p className="text-white text-xl text-center font-space mt-16">No events to show</p>
          )}
        </div>
      )}
      {currentTab == TabType.UPCOMING && (
        <div className="grid gap-5">
          {events?.upcoming.length > 0 ? (
            events.upcoming.map((event: Event) => {
              return (
                <EventCardSmall
                  key={event.id}
                  event={event}
                  type={undefined}
                  props={undefined}
                  isInactive={true}
                  showCountdown={false}
                />
              );
            })
          ) : (
            <p className="text-white text-xl text-center font-space mt-16">No events to show</p>
          )}
        </div>
      )}
      {currentTab == TabType.PAST && (
        <div className="grid gap-5">
          {events?.past.length > 0 ? (
            events.past.map((event: Event) => {
              return (
                <EventCardSmall
                  key={event.id}
                  event={event}
                  type={undefined}
                  props={undefined}
                  isInactive={!isActive()}
                  showCountdown={false}
                />
              );
            })
          ) : (
            <p className="text-white text-xl text-center font-space mt-16">No events to show</p>
          )}
        </div>
      )}
    </div>
  );
}

export default EventsFeed;
