import React from 'react';
import { Comment as CommentType } from '../../types/Comment';
import Avatar from './icons/Avatar';

interface CommentProps {
  comment: CommentType;
  isPreview: boolean;
}

export default function Comment({ comment, isPreview }: CommentProps) {
  return (
    <div className={`bg-white ${isPreview ? '' : 'px-5 py-3 rounded-[20px]'}`}>
      <div className="flex items-start">
        <div className="avatar w-8 mr-2">
          <div className="w-24 rounded-full">
            {comment?.user?.profileImage ? <img src={comment.user.profileImage} /> : <Avatar />}
          </div>
        </div>
        <div className="flex flex-col">
          <p className="text-black leading-5 font-medium text-sm mb-1">{comment?.user?.username}</p>
          <p className="text-black mr-2 font-light	text-xs	line-clamp-2">{comment?.text}</p>
        </div>
      </div>
    </div>
  );
}
