import React, { useState, useEffect } from 'react';
import { Device } from '@capacitor/device';

export default function PhotoUpload({ progress, handleChange, pickImages }) {
  const [isMobileWeb, setisMobileWeb] = useState(false);

  useEffect(() => {
    Device.getInfo().then(info => {
      setisMobileWeb(
        (info.operatingSystem == 'android' || info.operatingSystem == 'ios') &&
          info.platform == 'web'
      );
    });
  }, [isMobileWeb]);

  const UploadButton = () => {
    if (isMobileWeb) {
      return (
        <label
          htmlFor="file-upload"
          className="absolute sticky ml-auto mr-auto w-[64px] left-0 right-0 bottom-[50px] bg-purple text-white rounded-full h-[64px] w-[64px] cursor-pointer z-50 flex justify-center items-center"
        >
          <svg
            width="28"
            height="28"
            viewBox="0 0 28 28"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              fillRule="evenodd"
              clipRule="evenodd"
              d="M15.1588 5.69727C15.0914 5.11704 14.5983 4.66666 14 4.66666C13.3556 4.66666 12.8333 5.18899 12.8333 5.83332V12.8333H5.83329L5.69723 12.8412C5.11701 12.9086 4.66663 13.4017 4.66663 14C4.66663 14.6443 5.18896 15.1667 5.83329 15.1667H12.8333V22.1667L12.8411 22.3027C12.9085 22.8829 13.4017 23.3333 14 23.3333C14.6443 23.3333 15.1666 22.811 15.1666 22.1667V15.1667H22.1666L22.3027 15.1588C22.8829 15.0914 23.3333 14.5983 23.3333 14C23.3333 13.3557 22.811 12.8333 22.1666 12.8333H15.1666V5.83332L15.1588 5.69727Z"
              fill="#FAFAFA"
            />
          </svg>
        </label>
      );
    } else {
      return (
        <button
          className="absolute sticky ml-auto mr-auto w-[64px] left-0 right-0 bottom-[50px] bg-purple text-white rounded-full h-[64px] w-[64px] cursor-pointer z-50 flex justify-center items-center"
          onClick={pickImages}
        >
          <svg
            width="28"
            height="28"
            viewBox="0 0 28 28"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              fillRule="evenodd"
              clipRule="evenodd"
              d="M15.1588 5.69727C15.0914 5.11704 14.5983 4.66666 14 4.66666C13.3556 4.66666 12.8333 5.18899 12.8333 5.83332V12.8333H5.83329L5.69723 12.8412C5.11701 12.9086 4.66663 13.4017 4.66663 14C4.66663 14.6443 5.18896 15.1667 5.83329 15.1667H12.8333V22.1667L12.8411 22.3027C12.9085 22.8829 13.4017 23.3333 14 23.3333C14.6443 23.3333 15.1666 22.811 15.1666 22.1667V15.1667H22.1666L22.3027 15.1588C22.8829 15.0914 23.3333 14.5983 23.3333 14C23.3333 13.3557 22.811 12.8333 22.1666 12.8333H15.1666V5.83332L15.1588 5.69727Z"
              fill="#FAFAFA"
            />
          </svg>
        </button>
      );
    }
  };
  return (
    <>
      {isMobileWeb && (
        <input
          id="file-upload"
          name="imgFile"
          accept="video/*"
          type="file"
          className=" w-0 h-0 hidden"
          onChange={handleChange}
        />
      )}
      {progress < 0 && <UploadButton />}
    </>
  );
}
