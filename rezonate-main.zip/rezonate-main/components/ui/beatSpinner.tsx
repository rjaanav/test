import React, { CSSProperties } from 'react';
import BeatLoader from 'react-spinners/BeatLoader';

const override: CSSProperties = {
  position: 'relative',
  margin: 'auto auto',
  borderColor: 'red',
  left: 0,
  right: 0,
  top: 0,
  bottom: 0,
};

export default function BeatSpinner() {
  return (
    <div className="m-auto flex items-center">
      <BeatLoader
        color={'#FAFAFA'}
        loading={true}
        size={20}
        aria-label="Loading Spinner"
        data-testid="loader"
        speedMultiplier={0.75}
        cssOverride={override}
      />
    </div>
  );
}
