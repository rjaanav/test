import React, { CSSProperties, useState } from 'react';
import MapPin from './MapPin';
import RightArrow from './icons/RightArrow';
import { Event } from '../../types/Event';
import Button from './Button';
import Link from 'next/link';
import PulseSpinner from './pulseSpinner';
import { IonRouterLink } from '@ionic/react';
import Countdown from './countdown';
import { isPast } from 'utils/dateUtils';

interface CardProps extends JSX.Element {
  event: Event;
  showDetails: boolean;
}

export default function Card({ event, showDetails }: CardProps) {
  if (!event) {
    return (
      <div className="card w-full min-w-[380px] min-h-[500px] sm:w-96 bg-white shadow-xl mx-auto">
        <PulseSpinner />
      </div>
    );
  }

  return (
    <div className="card w-full sm:w-96 bg-white shadow-xl mx-auto">
      <figure>
        <img className="object-cover w-full max-h-60" src={event.flyerImage} alt="Shoes" />
      </figure>
      <div className="card-body pt-4 pb-6 gap-0 px-6">
        <p className="font-space text-lightBlack text-base uppercase font-bold">
          {new Date(event.startDateTime).toLocaleDateString('en-US', {
            month: 'short',
            day: 'numeric',
          })}
        </p>
        <h2 className="card-title font-space text-black text-4xl mt-2 mb-4">{event.title}</h2>
        <div className="flex flex-row">
          <div className="w-6 h-6">
            <MapPin />
          </div>
          <p className="font-space text-black ml-1 text-base font-light	">
            {event.venue.displayName}
          </p>
        </div>
        <div className="mt-4">
          {event.closeDateTime && !isPast(event.closeDateTime) && (
            <Countdown targetDate={new Date(event.closeDateTime)} isSmall={false} />
          )}
        </div>
        <div className="card-actions">
          {!showDetails ? (
            <IonRouterLink href={`/events/${event.id}`} className="w-full">
              <Button label="View event">
                Take a Look <RightArrow />
              </Button>
            </IonRouterLink>
          ) : (
            <div className="font-space mt-4">
              <p className="text-black font-bold mb-2">Message from the artist:</p>
              <p className="text-black font-light	">{event.artistMessage}</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
