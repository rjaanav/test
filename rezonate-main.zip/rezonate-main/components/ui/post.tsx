import React, { useEffect, useState } from 'react';
import Username from './username';
// import VideoOptions from './videoOptions';
import PostActions from './postActions';
import Comment from './comment';
import ShowMoreComments from './showMoreComments';
import Video from './video';
import { Post as PostType } from '../../types/Post';
import Toast from './toast';
import { getBlob, getDownloadURL, ref } from 'firebase/storage';
import { storage } from '../../firebase';
import { Directory, Filesystem } from '@capacitor/filesystem';
import { Device } from '@capacitor/device';
import { Media, MediaSaveOptions } from '@capacitor-community/media';

interface PostProps {
  post: PostType;
}

export async function base64FromPath(path: string): Promise<string> {
  const response = await fetch(path);
  const blob = await response.blob();
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = reject;
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        resolve(reader.result);
      } else {
        reject('method did not return a string');
      }
    };
    reader.readAsDataURL(blob);
  });
}

const ensureRezonateAlbum = async () => {
  const { albums } = await Media.getAlbums();
  const rezonateAlbum = albums.find(a => a.name === 'Rezonate');
  if (rezonateAlbum) {
    return rezonateAlbum.identifier;
  } else {
    await Media.createAlbum({ name: 'Rezonate' });
    const rezonateAlbum = albums.find(a => a.name === 'Rezonate');
    return rezonateAlbum.identifier;
  }
};

const convertBlobToBase64 = (blob: Blob) =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = reject;
    reader.onload = () => {
      resolve(reader.result);
    };
    reader.readAsDataURL(blob);
  });

export default function Post({ post }: PostProps) {
  const [videoDownloaded, setVideoDownloaded] = useState(false);
  const [videoUrl, setVideoUrl] = useState('');

  async function loadVideo() {
    const storageRef = ref(storage, `events/${post.eventID}/${post.id}/video.mp4`);
    const url = await getDownloadURL(storageRef)
      .then(url => {
        setVideoUrl(url);
      })
      .catch(error => {
        console.log(error);
      });
  }

  async function HandleVideoDownload() {
    console.log('downloading video...');
    const storageRef = ref(storage, `events/${post.eventID}/${post.id}/video.mp4`);
    const info = await Device.getInfo();

    if (
      info.platform == 'web' &&
      (info.operatingSystem == 'mac' || info.operatingSystem == 'windows')
    ) {
      await getBlob(storageRef)
        .then(async blob => {
          // // convert to base64 data, which the Filesystem plugin requires
          const base64Data = (await convertBlobToBase64(blob)) as string;
          const url = window.URL.createObjectURL(blob);
          const link = document.createElement('a');
          link.href = url;
          link.setAttribute('download', `rezonate.mp4`);

          // Append to html link element page
          document.body.appendChild(link);

          // Start download
          link.click();

          // Clean up and remove the link
          link.parentNode!.removeChild(link);
        })
        .catch(error => {
          console.log('could not get video', error);
        });
    } else if (info.platform != 'web') {
      // TODO: Fix mobile download functionality
      const url = await getDownloadURL(storageRef);
      const response = await fetch(url);
      const blob = await response.blob();
      const base64Data = (await convertBlobToBase64(blob)) as string;
      let opts: MediaSaveOptions = {
        path: base64Data,
        albumIdentifier: await ensureRezonateAlbum(),
      };
      await Media.saveVideo(opts);
    } else {
      alert('Please use the computer or our app to download file 👾');
      return;
    }
    setVideoDownloaded(true);
    // to mkae toast disappear
    setTimeout(() => {
      setVideoDownloaded(false);
    }, 2000);
  }

  useEffect(() => {
    if (!videoUrl) {
      loadVideo();
    }
  }, [videoUrl]);

  return (
    <div
      id={`post-${post.id}`}
      className="card w-full sm:w-96 bg-black shadow-xl mb-4 mx-auto	overflow-hidden	"
    >
      <figure
        className="relative bg-black"
        style={{ alignItems: 'flex-start', justifyContent: 'space-between' }}
      >
        <div className={'px-5 pt-5 absolute flex w-full justify-between'}>
          <Username
            user={{
              id: post.author.id,
              profileImage: post.author.profileImage,
              username: post.author.username,
              email: null,
            }}
            key={'username'}
            type={undefined}
            props={undefined}
          />
          {/* disable for now*/}
          {/* <VideoOptions /> */}
        </div>
        <Video postID={post.id} src={videoUrl} />
        <Toast videoDownloaded={videoDownloaded} />
      </figure>
      <div className="card-body px-5 py-4 bg-white" style={{ gap: '0px' }}>
        <>
          <PostActions post={post} handleVideoDownload={HandleVideoDownload} />
          {post.comments && post.comments.length > 0 ? (
            <div className="mt-4">
              {post.comments
                .filter((item, idx) => idx < 2)
                .map((comment, index) => {
                  return (
                    <div
                      key={comment.id}
                      className={index < post.comments.length - 1 ? 'mb-3' : ''}
                    >
                      <Comment isPreview={true} comment={comment} />
                    </div>
                  );
                })}
              <ShowMoreComments
                numComments={post.comments.length}
                eventID={post.eventID}
                postID={post.id}
              />
            </div>
          ) : (
            ''
          )}
        </>
      </div>
    </div>
  );
}
