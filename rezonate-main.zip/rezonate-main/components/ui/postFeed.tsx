import Post from './post';

function PostFeed({ PostCards }) {
  let PostCardsComponent = () => {
    if (PostCards.length > 0) {
      return (
        <div>
          {PostCards.map(post => {
            return <Post key={post.id} post={post} />;
          })}
        </div>
      );
    } else {
      return (
        <p className="font-space text-white text-center text-xl mt-10">
          No posts yet! Stay tuned...
        </p>
      );
    }
  };

  return <PostCardsComponent />;
}

export default PostFeed;
