import { User } from '../../types/User';
import Avatar from './icons/Avatar';

interface ProfileImageProps {
  url?: string;
  size: string;
}

export default function ProfileImage({ url, size }: ProfileImageProps) {
  return (
    <div className={`${size} rounded-full overflow-hidden`}>
      {url ? <img src={url} referrerPolicy="no-referrer" /> : <Avatar />}
    </div>
  );
}
