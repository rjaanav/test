import React, { CSSProperties } from 'react';
import MapPin from './MapPin';
import RightArrow from './icons/RightArrow';
import { Event } from '../../types/Event';
import Button from './Button';
import Link from 'next/link';
import PulseSpinner from './pulseSpinner';
import { IonItem, IonRouterLink } from '@ionic/react';
import CountdownTimer from './countdown';
import Countdown from './countdown';

interface CardProps extends JSX.Element {
  event: Event;
  isInactive: boolean;
  showCountdown: boolean;
}

export default function EventCardSmall({ event, isInactive, showCountdown }: CardProps) {
  if (!event) {
    return (
      <div className="card w-full min-w-[380px] min-h-[500px] sm:w-96 bg-white shadow-xl mx-auto">
        <PulseSpinner />
      </div>
    );
  }

  return (
    <IonRouterLink
      routerLink={`/events/${event.id}`}
      className="w-full"
      style={{ pointerEvents: isInactive ? 'none' : 'auto' }}
    >
      <div className="flex relative z-50 w-full min-h-[122px] sm:w-96 bg-white shadow-xl mx-auto p-4 rounded-xl">
        <img
          className="object-cover min-h-full w-[90px] aspect-square		 rounded"
          src={event.flyerImage}
          alt="Shoes"
        />
        <div className="card-body flex justify-between pl-4 pt-0 pr-2 pb-0 gap-0">
          <span className="font-space text-lightBlack text-small uppercase">
            {new Date(event.startDateTime).toLocaleDateString('en-US', {
              month: 'short',
              day: 'numeric',
            })}
          </span>
          <h2 className="card-title m-0 font-space text-black text-2xl">
            {event.venue.displayName}
          </h2>
          <div className="flex flex-row items-center">
            <div className="w-4 h-4 xs:w-6 xs:h-6">
              <MapPin />
            </div>
            <p className="font-space text-black ml-1 text-xs xs:text-base font-light	">{`${event.venue.city}, ${event.venue.state}`}</p>
          </div>
          <div className="mt-2 text-xs xs:text-base">
            {event.closeDateTime && showCountdown && (
              <Countdown targetDate={new Date(event.closeDateTime)} isSmall={CountdownTimer} />
            )}
          </div>
        </div>
        <div
          className={`card-actions mt-auto mb-auto ${isInactive ? 'opacity-20' : 'opacity-100'}`}
        >
          <Button
            label="View event"
            className="min-h-0 h-[30px] w-[30px] flex justify-center items-center rounded bg-purple"
          >
            <svg
              width="8"
              height="12"
              viewBox="0 0 8 12"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                fillRule="evenodd"
                clipRule="evenodd"
                d="M0.91107 0.41107C1.21147 0.110667 1.68417 0.0875586 2.01108 0.341746L2.08958 0.41107L7.08958 5.41107C7.38998 5.71147 7.41309 6.18417 7.15891 6.51108L7.08958 6.58958L2.08958 11.5896C1.76414 11.915 1.23651 11.915 0.91107 11.5896C0.610667 11.2892 0.587559 10.8165 0.841746 10.4896L0.91107 10.4111L5.32116 6.00033L0.91107 1.58958C0.610667 1.28918 0.587559 0.816485 0.841746 0.489576L0.91107 0.41107Z"
                fill="#FAFAFA"
              />
            </svg>
          </Button>
        </div>
      </div>
    </IonRouterLink>
  );
}
