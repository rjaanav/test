import React from 'react';
import { User } from '../../types/User';
import Avatar from './icons/Avatar';

interface UsernameProps extends JSX.Element {
  user: User;
}

export default function Username({ user }: UsernameProps) {
  return (
    <div className="flex items-center">
      <div className="avatar w-8 mr-2">
        <div className="w-24 rounded-full z-[3]">
          {user.profileImage ? <img src={user.profileImage} /> : <Avatar />}
        </div>
      </div>
      <p className="font-space text-white leading-5 z-10">{user.username}</p>
    </div>
  );
}
