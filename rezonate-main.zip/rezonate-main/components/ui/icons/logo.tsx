import React from 'react';

function Logo() {
  return (
    <div className="p-0.5">
      <svg
        width="14"
        height="22"
        viewBox="0 0 14 22"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          d="M3.88475 22V11.12C3.88475 6.992 7.24475 3.696 11.3408 3.696H13.8048V0.303999H11.2768C5.26075 0.303999 0.20475 4.976 0.20475 11.088V22H3.88475Z"
          fill="#FAFAFA"
        />
      </svg>
    </div>
  );
}

export default Logo;
