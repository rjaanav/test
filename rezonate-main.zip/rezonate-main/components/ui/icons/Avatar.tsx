import React from 'react';

function Avatar() {
  return (
    <div className="relative z-10 w-full">
      <svg viewBox="0 0 50 51" fill="none" xmlns="http://www.w3.org/2000/svg">
        <g filter="url(#filter0_dd_55_1129)">
          <circle cx="25" cy="25" r="24" fill="#3F28CC" />
        </g>
        <path
          fillRule="evenodd"
          clipRule="evenodd"
          d="M22 29C20.3431 29 19 30.3431 19 32C19 32.5523 19.4477 33 20 33H30C30.5523 33 31 32.5523 31 32C31 30.3431 29.6569 29 28 29H22ZM17 32C17 29.2386 19.2386 27 22 27H28C30.7614 27 33 29.2386 33 32C33 33.6569 31.6569 35 30 35H20C18.3431 35 17 33.6569 17 32Z"
          fill="#FAFAFA"
        />
        <path
          fillRule="evenodd"
          clipRule="evenodd"
          d="M25 17C23.3431 17 22 18.3431 22 20C22 21.6569 23.3431 23 25 23C26.6569 23 28 21.6569 28 20C28 18.3431 26.6569 17 25 17ZM20 20C20 17.2386 22.2386 15 25 15C27.7614 15 30 17.2386 30 20C30 22.7614 27.7614 25 25 25C22.2386 25 20 22.7614 20 20Z"
          fill="#FAFAFA"
        />
        <defs>
          <filter
            id="filter0_dd_55_1129"
            x="0"
            y="0"
            width="50"
            height="51"
            filterUnits="userSpaceOnUse"
            colorInterpolationFilters="sRGB"
          >
            <feFlood floodOpacity="0" result="BackgroundImageFix" />
            <feColorMatrix
              in="SourceAlpha"
              type="matrix"
              values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
              result="hardAlpha"
            />
            <feOffset dy="1" />
            <feGaussianBlur stdDeviation="0.5" />
            <feComposite in2="hardAlpha" operator="out" />
            <feColorMatrix
              type="matrix"
              values="0 0 0 0 0.188235 0 0 0 0 0.192157 0 0 0 0 0.2 0 0 0 0.1 0"
            />
            <feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_55_1129" />
            <feColorMatrix
              in="SourceAlpha"
              type="matrix"
              values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
              result="hardAlpha"
            />
            <feOffset />
            <feGaussianBlur stdDeviation="0.5" />
            <feComposite in2="hardAlpha" operator="out" />
            <feColorMatrix
              type="matrix"
              values="0 0 0 0 0.188235 0 0 0 0 0.192157 0 0 0 0 0.2 0 0 0 0.05 0"
            />
            <feBlend
              mode="normal"
              in2="effect1_dropShadow_55_1129"
              result="effect2_dropShadow_55_1129"
            />
            <feBlend
              mode="normal"
              in="SourceGraphic"
              in2="effect2_dropShadow_55_1129"
              result="shape"
            />
          </filter>
        </defs>
      </svg>
    </div>
  );
}

export default Avatar;
