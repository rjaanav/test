import { IonRouterLink } from '@ionic/react';
import Link from 'next/link';
import React, { useState } from 'react';
import Store from 'store';
import LeftArrowCircle from './icons/LeftArrowCircle';
import ProfileImage from './profileImage';
import { useHistory } from 'react-router-dom';
import { signMeOut } from 'utils/signMeOut';
import Logo from './icons/logo';
import { useEffect } from 'react';
import { getAuth, onAuthStateChanged } from 'firebase/auth';
import { User } from 'types/User';

interface ControlBarProps {
  backLink: boolean;
  centerText?: string;
  hasLogout: boolean;
  logo: boolean;
  profileActions: boolean;
  isSticky: boolean;
}

export default function ControlBar({
  backLink,
  centerText,
  hasLogout,
  logo,
  profileActions,
  isSticky,
}: ControlBarProps) {
  const [authenticated, setAuthenticated] = useState<boolean>(null);
  const [imageUrl, setImageUrl] = useState<string>('');

  const history = useHistory();

  const auth = getAuth();

  useEffect(() => {
    onAuthStateChanged(auth, user => {
      if (user) {
        setAuthenticated(true);
        setImageUrl(user.photoURL);
      } else {
        setAuthenticated(false);
      }
    });
  }, [auth]);

  function ProfileComponent() {
    if (authenticated) {
      return (
        <IonRouterLink href={'/my-profile'} className="flex items-center">
          <ProfileImage url={imageUrl} size={'w-10'}></ProfileImage>
        </IonRouterLink>
      );
    } else {
      return (
        <IonRouterLink href={'/login'} className="flex items-center">
          <button className="font-space py-1.5 px-4 text-sm md:text-base md:py-2 md:px-5 border-white border-[1px] border-solid rounded text-white font-bold	">
            Sign In
          </button>
        </IonRouterLink>
      );
    }
  }

  function handleSignOut() {
    signMeOut();
  }

  return (
    <div
      className={`z-50 top-0 flex flex-row justify-between items-center p-2 text-[14px] h-20  ${
        isSticky ? 'sticky' : 'relative'
      }`}
    >
      {backLink ? (
        <button
          onClick={() => history.goBack()}
          className={'flex items-center justify-self-start z-10 text-white font-space'}
        >
          <>
            <LeftArrowCircle /> <p className="ml-2 font-bold text-base">Back</p>
          </>
        </button>
      ) : (
        <></>
      )}
      {logo ? (
        <IonRouterLink href="/">
          <Logo />
        </IonRouterLink>
      ) : (
        <></>
      )}
      {centerText ? (
        <p className="absolute left-0 right-0 w-fit mx-auto font-space text-[14px] z-10 font-align-top text-base font-bold justify-self-center mx-auto text-white leading-4	line-clamp-2 text-center w-[130px] max-w-[180px] xs:w-auto sm:max-w-[280px]">
          {centerText}
        </p>
      ) : (
        <></>
      )}
      {hasLogout ? (
        <button
          onClick={handleSignOut}
          className="font-space py-1.5 px-4 text-sm md:text-base md:py-2 md:px-5 border-white border-[1px] border-solid rounded text-white font-bold	"
        >
          Log Out
        </button>
      ) : (
        <></>
      )}
      {profileActions ? <ProfileComponent /> : <></>}
    </div>
  );
}
