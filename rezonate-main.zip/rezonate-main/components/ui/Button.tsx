import React from 'react';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  /** optionally pass in a classname, will use default styling if undefined */
  className?: string;
  /** required label for a11y */
  label: string;
  disabled?: boolean;
  onClick?: any;
}

export default function Button({ children, className, label, onClick }: ButtonProps) {
  return (
    <button
      className={className ? className : 'btn btn-primary rounded w-full font-space'}
      aria-label={label}
      onClick={onClick}
    >
      {children}
    </button>
  );
}
