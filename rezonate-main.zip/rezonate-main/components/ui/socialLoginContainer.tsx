import React, { useState } from 'react';
import FacebookLogo from './icons/facebook';
import AppleLogo from './icons/apple';
import GoogleLogo from './icons/google';

export default function SocialLoginContainer({ googleSignIn }) {
  return (
    <div className="grid gap-4">
      {/* <button
        onClick={() => FacebookLogin()}
        className="rounded bg-white text-black flex justify-center w-full py-3 px-4 items-center"
      >
        <FacebookLogo />
        <p className="ml-3">{action} with Facebook</p>
      </button> */}
      <button
        onClick={() => googleSignIn()}
        className="rounded-lg bg-white text-black flex justify-center w-full py-3 px-4 items-center border-solid	 border-2 border-borderGrey"
      >
        <GoogleLogo />
        <p className="ml-3 font-medium">Continue with Google</p>
      </button>
      {/* <button
        onClick={() => AppleLogin()}
        className="rounded bg-white text-black flex justify-center w-full py-3 px-4 items-center"
      >
        <AppleLogo />
        <p className="ml-3">{action} with Apple</p>
      </button> */}
      {/* <p className="text-l text-center my-8">
        {isSignup ? 'Already have an account? ' : "Don't have an account yet? "}
        <button onClick={() => setIsSignup(!isSignup)}>
          <b>{isSignup ? 'Log In' : 'Sign up'}</b>
        </button>
      </p> */}
    </div>
  );
}
