import React from 'react';
import Success from './icons/success';
import styles from './toast.module.css';
import resolveConfig from 'tailwindcss/resolveConfig';
import tailwindConfig from '../../tailwind.config.js';

const fullConfig = resolveConfig(tailwindConfig);

export default function Toast({ videoDownloaded }) {
  return (
    <div
      className={`absolute w-40 h-9 text-white bg-darkGrey inset-0 font-space	m-auto rounded opacity-50 flex justify-center items-center			 ${
        videoDownloaded ? styles.fadeIn : styles.fadeOut
      }`}
    >
      <Success color={fullConfig.theme.colors.white} />
      <p className="pl-1.5	">Downloaded</p>
    </div>
  );
}
