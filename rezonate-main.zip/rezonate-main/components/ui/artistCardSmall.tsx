import React from 'react';
import Button from './Button';
import PulseSpinner from './pulseSpinner';
import { IonRouterLink } from '@ionic/react';
import { Artist } from 'types/Artist';

interface CardProps extends JSX.Element {
  artist: Artist;
}

export default function ArtistCardSmall({ artist }: CardProps) {
  const rezonateDate = new Date(artist.user.createdAt).toLocaleDateString('en-US', {
    month: 'short',
    year: 'numeric',
  });
  if (!artist) {
    return (
      <div className="card w-full min-w-[380px] min-h-[500px] sm:w-96 bg-white shadow-xl mx-auto">
        <PulseSpinner />
      </div>
    );
  }

  return (
    <IonRouterLink routerLink={`/artists/${artist.user.username}`} className="w-full">
      <div className="flex relative z-50 w-full min-h-[122px] sm:w-96 bg-white shadow-xl mx-auto rounded-xl overflow-hidden	">
        <img
          className="object-cover min-h-full w-[129px] aspect-square"
          src={artist.user.profileImage}
          alt="Shoes"
        />
        <div className="card-body flex justify-center pl-4 pt-0 pr-2 pb-0 gap-0">
          <h2 className="card-title m-0 font-space text-black text-2xl">{artist.displayName}</h2>
          <div className="flex flex-row items-center">
            <p className="font-space text-black text-xs font-light">{`On Rezonate since ${rezonateDate}`}</p>
          </div>
        </div>
        <div className="card-actions mt-auto mb-auto pr-6	pl-2">
          <Button
            label="View event"
            className="min-h-0 h-[30px] w-[30px] flex justify-center items-center rounded bg-purple"
          >
            <svg
              width="8"
              height="12"
              viewBox="0 0 8 12"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                fillRule="evenodd"
                clipRule="evenodd"
                d="M0.91107 0.41107C1.21147 0.110667 1.68417 0.0875586 2.01108 0.341746L2.08958 0.41107L7.08958 5.41107C7.38998 5.71147 7.41309 6.18417 7.15891 6.51108L7.08958 6.58958L2.08958 11.5896C1.76414 11.915 1.23651 11.915 0.91107 11.5896C0.610667 11.2892 0.587559 10.8165 0.841746 10.4896L0.91107 10.4111L5.32116 6.00033L0.91107 1.58958C0.610667 1.28918 0.587559 0.816485 0.841746 0.489576L0.91107 0.41107Z"
                fill="#FAFAFA"
              />
            </svg>
          </Button>
        </div>
      </div>
    </IonRouterLink>
  );
}
