import React, { useRef, useState, useCallback, useEffect } from 'react';
import styles from './video.module.css';
import VolumeToggle from './volumeToggle';
import PulseSpinner from './pulseSpinner';

const Video = ({ postID, src }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(true);
  const [hasLoaded, setHasLoaded] = useState(false);
  const [useControls, setUseControls] = useState(false);
  const videoRef = useRef(null);

  const playOrPause = useCallback(() => {
    if (videoRef.current.paused || videoRef.current.ended) {
      videoRef.current.play();
    } else {
      videoRef.current.pause();
    }
  }, []);

  function handleIntersect(entries, observer) {
    entries.forEach(entry => {
      let videoElement = entry.target.querySelectorAll('video').item(0);
      if (entry.isIntersecting && videoElement) {
        videoElement.play().catch(error => {
          // Detect low power mode
          setUseControls(true);
        });
      } else if (videoElement) {
        videoElement.pause();
      }
    });
  }

  let options = {
    rootMargin: '0px',
    threshold: 0.5,
  };
  let observer = new IntersectionObserver(handleIntersect, options);

  useEffect(() => {
    let postContainer = document.querySelector(`#post-${postID}`);
    if (postContainer) {
      observer.observe(postContainer);
    }
  }, []);

  const onPlay = useCallback(() => setIsPlaying(true), []);

  const onPause = useCallback(() => setIsPlaying(false), []);

  const onLoad = useCallback(() => setHasLoaded(true), []);

  function ToggleSound() {
    setIsMuted(!isMuted);
  }

  return (
    <div
      className={`${styles.videoWrapper} w-full max-h-120 flex items-center justify-center max-h-[75vh] bg-backgroundBlack overflow-hidden rounded-t-2xl`}
      // onClick={playOrPause}
    >
      {src ? (
        <>
          {!hasLoaded && <PulseSpinner />}
          <video
            onPlay={onPlay}
            onPause={onPause}
            onLoadedData={onLoad}
            ref={videoRef}
            className="video object-center w-[100%] object-cover"
            src={src}
            playsInline
            autoPlay={true}
            loop={true}
            webkit-playsinline="true"
            muted={isMuted}
          />
        </>
      ) : (
        <div className="h-[200px] flex items-center text-white font-space">
          Error loading video 😢
        </div>
      )}
      <VolumeToggle toggleSound={ToggleSound} isMutedProp={isMuted} />
      {/* Temporarily disable controls */}
      {useControls && (
        <div className={styles.controls} onClick={playOrPause}>
          {/* <img
            src={'/play.png'}
            alt="play button"
            className={`${styles.videoControl} ${
              isPlaying ? `${styles.controlHidden}` : `${styles.controlShown}`
            }`}
          /> */}
        </div>
      )}
    </div>
  );
};

export default Video;
