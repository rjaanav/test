import { Fragment, useState } from 'react';
import { Menu, Transition } from '@headlessui/react';
import { ChevronDownIcon } from '@heroicons/react/20/solid';

function classNames(...classes) {
  return classes.filter(Boolean).join(' ');
}

const sortOptions: string[] = ['Recently Uploaded', 'Most Likes', 'Most Comments'];

export default function Dropdown({ sortPosts }) {
  const [sortMethod, setSortMethod] = useState(sortOptions[0]);

  function sortFeed(orderOptionsIndex: number) {
    setSortMethod(sortOptions[orderOptionsIndex]);
    sortPosts(sortOptions[orderOptionsIndex]);
  }

  return (
    <Menu as="div" className="relative inline-block text-left w-[250px] z-50 my-4 font-light	">
      <div>
        <Menu.Button className="inline-flex w-full font-space justify-between rounded border border-gray-300 bg-white px-4 py-2 text-sm text-black shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 focus:ring-offset-gray-100">
          {sortMethod}
          <ChevronDownIcon className="-mr-1 ml-2 h-5 w-5" aria-hidden="true" />
        </Menu.Button>
      </div>

      <Transition
        as={Fragment}
        enter="transition ease-out duration-100"
        enterFrom="transform opacity-0 scale-95"
        enterTo="transform opacity-100 scale-100"
        leave="transition ease-in duration-75"
        leaveFrom="transform opacity-100 scale-100"
        leaveTo="transform opacity-0 scale-95"
      >
        <Menu.Items className="absolute left-0 z-10 mt-0.5 w-full origin-top-left rounded bg-white shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none">
          <div className="py-1">
            <Menu.Item>
              {({ active, close }) => (
                <>
                  <button
                    onClick={() => {
                      sortFeed(0);
                      close();
                    }}
                    className={classNames(
                      active ? 'bg-gray-100 text-gray-900' : 'text-gray-700',
                      'block px-4 py-2 text-sm text-black'
                    )}
                  >
                    {sortOptions[0]}
                  </button>
                </>
              )}
            </Menu.Item>
            <Menu.Item>
              {({ active, close }) => (
                <>
                  <button
                    onClick={() => {
                      sortFeed(1);
                      close();
                    }}
                    className={classNames(
                      active ? 'bg-gray-100 text-gray-900' : 'text-gray-700',
                      'block px-4 py-2 text-sm text-black'
                    )}
                  >
                    {sortOptions[1]}
                  </button>
                </>
              )}
            </Menu.Item>
            <Menu.Item>
              {({ active, close }) => (
                <>
                  <button
                    onClick={() => {
                      sortFeed(2);
                      close();
                    }}
                    className={classNames(
                      active ? 'bg-gray-100 text-gray-900' : 'text-gray-700',
                      'block px-4 py-2 text-sm text-black'
                    )}
                  >
                    {sortOptions[2]}
                  </button>
                </>
              )}
            </Menu.Item>
          </div>
        </Menu.Items>
      </Transition>
    </Menu>
  );
}
