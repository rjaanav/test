import ProfileImage from './profileImage';
import { User } from 'types/User';
import ChartCircles from './icons/chartCircles';

export default function ProfileTopSection(user: User) {
  return (
    <div className={'mt-6 z-50 pb-6 border-darkGrey border-b-2'}>
      <div className={'flex flex-col justify-between items-center'}>
        <ProfileImage url={user.profileImage} size={'w-20 h-20'}></ProfileImage>
        {user?.createdAt && (
          <div className="flex mt-4	items-center">
            <ChartCircles />
            <p className="ml-1 font-space text-lightGrey font-light	">
              on Rezonate since {user.createdAt}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
