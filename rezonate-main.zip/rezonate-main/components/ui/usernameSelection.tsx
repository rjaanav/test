import React from 'react';
import Button from './Button';
import RightArrow from './icons/RightArrow';

export default function UsernameSelection() {
  return (
    <div>
      <p className="mb-1">Create a Username</p>
      <input
        className="bg-white text-black font-space py-2 px-4 mb-4 rounded w-full"
        placeholder="Enter username"
      ></input>
      <Button label={'Continue'}>
        <Button label="View event">
          Continue <RightArrow />
        </Button>
      </Button>
    </div>
  );
}
