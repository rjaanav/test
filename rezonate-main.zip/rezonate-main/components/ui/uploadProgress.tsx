import React from 'react';
import CloseIcon from './icons/close';

function UploadProgress({ progress, postFailure, clearUpload }) {
  const componentText = postFailure
    ? 'Upload failed. Try again.'
    : 'Upload in progress. Please stay on this page.';

  const color = postFailure ? 'bg-errorRed' : 'bg-primary';

  progress = postFailure ? '100' : progress;

  return (
    <div className="border-b-[1px] border-mediumGrey mb-2 w-screen ml-[-15px]">
      <div className="h-1 w-full dark:bg-neutral-600">
        <div className={`h-1 ${color}`} style={{ width: `${progress}%` }}></div>
      </div>
      <div className="flex justify-between px-4">
        <p className="font-space text-white text-xs py-4">{`${componentText}`}</p>
        {postFailure && (
          <button onClick={clearUpload} className="text-white">
            <CloseIcon />
          </button>
        )}
      </div>
    </div>
  );
}

export default UploadProgress;
