import React from 'react';
import Link from 'next/link';
import { IonRouterLink } from '@ionic/react';

export default function ShowMoreComments({ numComments, postID, eventID }) {
  function ComponentText() {
    const displayNumber = numComments - 2;
    const commentString = displayNumber > 1 ? 'comments' : 'comment';
    return `Show ${displayNumber} more ${commentString}`;
  }

  return (
    <div>
      {numComments > 2 ? (
        <IonRouterLink
          routerLink={`${eventID}/${postID}`}
          className="font-bold text-xs text-black font-space ml-10 mt-3 cursor-pointer"
        >
          {ComponentText()}
        </IonRouterLink>
      ) : (
        ''
      )}
    </div>
  );
}
